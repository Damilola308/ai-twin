# Ajo: Smart Credit for Nigeria (Product Design Concept)

![Overview](hero.png)

**What it is:** A fictional mobile credit product for Nigerians with thin or no formal credit history. It reads everyday money behaviour (bank transfers, bill payments, airtime) to build a fair score and offer transparent loans.
**Users:** Market traders, freelancers, gig workers and young salaried people, mostly iPhone and mid-range Android users on variable data.
**Locale:** NGN (₦), +234 numbers, BVN/NIN identity, bank payouts and auto-debit.
**Platform:** iOS, 5 key screens.

---

## 1. Onboarding
![Onboarding](mockup-01.png)

**Problem:** Long KYC forms and branch visits cause drop-off before a user sees any value.
**Solution:** Phone number first, BVN or NIN as fast-track options, and a trust note right below the primary button.
**Key decisions**
- One field on the first screen to reduce effort.
- BVN and NIN are offered as familiar, trusted identity options.
- Security reassurance sits where doubt appears.

**Metric:** Sign-up completion rate; time to first score.
**Test next:** OTP vs. BVN-first order; value-prop headline variants.

## 2. Credit Dashboard
![Credit dashboard](mockup-02.png)

**Problem:** A score alone does not tell users what to do next.
**Solution:** Available credit as the hero number, a score ring, three plain-language drivers and one recommended action.
**Key decisions**
- Lead with what the user can borrow, not the abstract score.
- Drivers use words like Strong, Good, Fair instead of jargon.
- Single next step to avoid decision overload.

**Metric:** % completing the recommended action within 7 days.
**Test next:** Ring vs. number-only; driver order.

## 3. Loan Offer
![Loan offer](mockup-03.png)

**Problem:** Borrowers distrust hidden fees and cannot compare amounts and terms easily.
**Solution:** An amount slider, term chips and a live breakdown ending in total repayment and monthly instalment.
**Key decisions**
- Total cost is visible before commitment.
- Payout bank and speed are stated up front.
- Controls are thumb-friendly and work on small screens.

**Metric:** Offer acceptance rate; fee-related support tickets.
**Test next:** Default term; weekly vs. monthly instalments.

## 4. Repayments
![Repayments](mockup-04.png)

**Problem:** Missed payments are often forgetfulness, not unwillingness.
**Solution:** Balance progress, a simple timeline, auto-repay and an early-payment score incentive.
**Key decisions**
- Status is shown with colour and text together.
- Auto-repay is on the screen, not buried in settings.
- Early repayment is rewarded.

**Metric:** On-time repayment rate; auto-repay adoption.
**Test next:** Reminder timing; wording of the early-pay incentive.

## 5. Business Insights
![Business insights](mockup-05.png)

**Problem:** Small business owners rarely see their cash flow, so they cannot time borrowing well.
**Solution:** Weekly money in and out, a highlighted best day and an insight that links to a relevant top-up.
**Key decisions**
- Week / Month / Year switcher keeps the screen simple.
- Insight card turns data into an action.
- Credit is positioned as a business tool, not just a loan.

**Metric:** Insight-to-offer click-through; repeat borrowing.
**Test next:** Insight tone and timing.

---

## My process
*Replace with your real process: user interviews, journey mapping, wireframes, usability tests and what you changed.*

## Tools
Figma, FigJam, Notion (replace with your own).
